#include "Bee.hpp"
#include "BeeStates.hpp"

using sf::Time;
using sf::Vector2f;

// TODO Start the Bee in the idle state
Bee::Bee(Vector2f const& center, Vector2f const& position)
    : GameSprite("graphics/bee.png", position), center(center), currentState(nullptr)
{
    // TODO Enter the current state if one exists
}

void
Bee::onNotify(TriggerEvent const& event)
{
    // TODO Let the current state handle the event and change state if appropriate
}

void
Bee::update(Time const& dt)
{
    // TODO Update the current state

    if (velocity.x == 0 && velocity.y == 0) { return; }

    Vector2f prevPosition = sprite.getPosition();
    Vector2f newPosition = prevPosition + dt.asSeconds() * speed * velocity;
    sprite.setPosition(newPosition);
}
