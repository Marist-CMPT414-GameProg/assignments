#include "BeeStates.hpp"
#include "Trigger.hpp"
#include "VectorMath.hpp"

#include <cmath>
#include <iostream>

using sf::Sprite;
using sf::Vector2f;

/* Forward declarations of auxiliary functions */

bool coinflip();
float random();

Bee::State::State(Bee& bee) : controlledBee(bee) {}

// TODO Implement your derives Bee states here
// ...

/* Auxiliary functions */

bool
coinflip()
{
    constexpr static int HALF_MAX = RAND_MAX / 2;
    return rand() < HALF_MAX;
}

float
random()
{
    return rand() / float(RAND_MAX);
}
